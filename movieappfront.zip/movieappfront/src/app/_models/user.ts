export interface User {
    confirmPassword: any;
    id: number;
    username: string;
    firstName: string;
    lastName: string;
    number: number;
    dateOfBirth: string;
    email: string;
    roles: string[];
    password: string;
    securityQuestion: string;
    securityAnswer: string;
  }
  