package com.cts.moviebooking.exception;

public class NotFoundException extends RuntimeException {
    public NotFoundException(String wishlist_not_found) {
    }
}
