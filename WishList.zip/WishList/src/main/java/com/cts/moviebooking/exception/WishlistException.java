package com.cts.moviebooking.exception;

public class WishlistException extends RuntimeException {

    public WishlistException(String message) {
        super(message);
    }
}
