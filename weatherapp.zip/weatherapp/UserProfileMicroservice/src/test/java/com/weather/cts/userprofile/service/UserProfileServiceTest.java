package com.weather.cts.userprofile.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.weather.cts.userprofile.exception.UserNameAlreadyExistsException;
import com.weather.cts.userprofile.model.UserProfile;
import com.weather.cts.userprofile.repo.UserRepository;

import static org.mockito.Mockito.when;
import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class UserProfileServiceTest {

    @InjectMocks
    UserServiceImpl userService;

    @Mock
    UserRepository userRepository;

    @Test
    public void testCreateUser() throws UserNameAlreadyExistsException {
        UserProfile user = new UserProfile();
        user.setUsername("testUser");
        user.setPassword("testPassword");
        user.setEmail("testEmail");
        user.setName("testName");

        when(userRepository.findByUsername(user.getUsername())).thenReturn(null);
        when(userRepository.save(user)).thenReturn(user);

        UserProfile result = userService.createUser(user);

        assertEquals(user.getUsername(), result.getUsername());
        assertEquals(user.getPassword(), result.getPassword());
        assertEquals(user.getEmail(), result.getEmail());
        assertEquals(user.getName(), result.getName());
    }

    @Test(expected = UserNameAlreadyExistsException.class)
    public void testCreateUserWithExistingUsername() throws UserNameAlreadyExistsException {
        UserProfile user = new UserProfile();
        user.setUsername("testUser");

        when(userRepository.findByUsername(user.getUsername())).thenReturn(user);

        userService.createUser(user);
    }
}
