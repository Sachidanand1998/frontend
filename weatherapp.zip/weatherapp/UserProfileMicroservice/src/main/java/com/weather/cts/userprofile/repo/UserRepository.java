package com.weather.cts.userprofile.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.weather.cts.userprofile.model.*;


@Repository
public interface UserRepository extends JpaRepository<UserProfile, Long>{
	UserProfile findByUsername(String username);
	
	UserProfile findByEmail(String email);
}



