package com.weather.cts.userprofile.kafka;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumerService {
  @KafkaListener(topics = "user_topic", groupId = "user_group")
  public void consumeMessage(String message) {
      System.out.println("Received message: " + message);
  }
}

