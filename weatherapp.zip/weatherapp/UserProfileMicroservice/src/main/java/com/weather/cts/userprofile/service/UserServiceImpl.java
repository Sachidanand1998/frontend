package com.weather.cts.userprofile.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.weather.cts.userprofile.model.*;
import com.weather.cts.userprofile.exception.*;

import com.weather.cts.userprofile.repo.*;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepo;

    @Override
    public UserProfile createUser(UserProfile user) throws UserNameAlreadyExistsException {
        if(userRepo.findByUsername(user.getUsername()) != null) {
            throw new UserNameAlreadyExistsException("username already exists with this user");
        }
        UserProfile savedUser = userRepo.save(user);
        return savedUser;
    }

    @Override
    public UserProfile findByUsername(String username) {
        return userRepo.findByUsername(username);
    }
}