package com.weather.cts.userprofile.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.weather.cts.userprofile.exception.UserNameAlreadyExistsException;
import com.weather.cts.userprofile.model.UserProfile;
import com.weather.cts.userprofile.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<UserProfile> createUser(@RequestBody UserProfile user) throws UserNameAlreadyExistsException {
        return new ResponseEntity<UserProfile>(userService.createUser(user),HttpStatus.CREATED);
    }

    @GetMapping("/{username}")
    public ResponseEntity<UserProfile> getUsername(@PathVariable String username) {
        UserProfile user = userService.findByUsername(username);
        if (user != null) {
            return new ResponseEntity<>(user, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
