package com.weather.cts.userprofile.exception;

public class UserNameAlreadyExistsException  extends  RuntimeException{


	private static final long serialVersionUID = 1L;


	public UserNameAlreadyExistsException(String message) {

		super(message);

	// TODO Auto-generated constructor stub

	}

}
