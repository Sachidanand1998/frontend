package com.weather.cts.userprofile.service;

import com.weather.cts.userprofile.exception.UserNameAlreadyExistsException;
import com.weather.cts.userprofile.model.UserProfile;

public interface UserService {
    UserProfile createUser(UserProfile user) throws UserNameAlreadyExistsException;
    UserProfile findByUsername(String username);
}
