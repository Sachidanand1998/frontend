import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';
import { WishlistService } from '../wishlist.service';
import { WeatherService } from '../weather.service';
import { FavoritesComponent } from './favorites.component';

describe('FavoritesComponent', () => {
  let component: FavoritesComponent;
  let fixture: ComponentFixture<FavoritesComponent>;
  let wishlistService: WishlistService;
  let snackBar: MatSnackBar;
  let weatherService: WeatherService;

  beforeEach(async () => {
    const wishlistServiceMock = {
      getWishlistByUsername: jasmine.createSpy('getWishlistByUsername').and.returnValue(of([{ id: '1', city: 'City1' }])),
      deleteWishlist: jasmine.createSpy('deleteWishlist').and.returnValue(of({}))
    };

    const snackBarMock = {
      open: jasmine.createSpy('open')
    };

    const weatherServiceMock = {
      getWeather: jasmine.createSpy('getWeather').and.returnValue(of({}))
    };

    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      declarations: [FavoritesComponent],
      providers: [
        { provide: WishlistService, useValue: wishlistServiceMock },
        { provide: MatSnackBar, useValue: snackBarMock },
        { provide: WeatherService, useValue: weatherServiceMock }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(FavoritesComponent);
    component = fixture.componentInstance;
    wishlistService = TestBed.inject(WishlistService);
    snackBar = TestBed.inject(MatSnackBar);
    weatherService = TestBed.inject(WeatherService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get wishlist by username on init', () => {
    component.ngOnInit();
    expect(wishlistService.getWishlistByUsername).toHaveBeenCalled();
    expect(component.wishlists).toEqual([{ id: '1', city: 'City1' }]);
  });

  it('should delete wishlist', () => {
    component.deleteWishlist('1');
    expect(wishlistService.deleteWishlist).toHaveBeenCalledWith('1');
    expect(snackBar.open).toHaveBeenCalledWith('City removed from wishlist successfully!', 'Close', { duration: 3000 });
  });
});
