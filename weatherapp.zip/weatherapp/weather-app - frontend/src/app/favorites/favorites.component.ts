import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { WishlistService } from '../wishlist.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { WeatherService } from '../weather.service';

@Component({
  selector: 'app-favorites',
  templateUrl: './favorites.component.html',
  styleUrls: ['./favorites.component.css']
})
export class FavoritesComponent implements OnInit {
  wishlists: any;
  username: string; 

  constructor(private wishlistService: WishlistService, private router: Router, private snackBar: MatSnackBar, private weatherService: WeatherService) { }

  ngOnInit() {
    this.username = localStorage.getItem('username') ?? ''; // If 'username' is null, an empty string will be used
    this.wishlistService.getWishlistByUsername(this.username).subscribe(data => {
      console.log(data); 
      this.wishlists = data;
    });
  }
  

  deleteWishlist(id: string) {
    this.wishlistService.deleteWishlist(id).subscribe(data => {
      // console.log(data);
      this.snackBar.open('City removed from wishlist successfully!', 'Close', {
        duration: 3000,
      });
      this.ngOnInit();
    });
  }

  goToSearchCity() {
    this.router.navigate(['/search']); 
  }

  getCityDetails(city: string) {
    this.weatherService.getWeather(city).subscribe(weatherDetails => {
      // Navigate to the city-details page with the weather details and the city name
      this.router.navigate(['/city-details', { weatherDetails: JSON.stringify(weatherDetails), city: city }]);
    });
  }
}
