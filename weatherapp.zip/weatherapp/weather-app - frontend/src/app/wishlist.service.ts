import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class WishlistService {
  private baseUrl = 'http://wishlist-devyanshi-env-1.eba-hzpqfper.ap-northeast-1.elasticbeanstalk.com/wishlist';

  constructor(private http: HttpClient) { }

  getWishlistByUsername(username: string): Observable<any> {
    return this.http.get(`${this.baseUrl}/user/${username}`);
  }

  createWishlist(wishlist: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}/add`, wishlist);
  }

  deleteWishlist(id: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/delete/${id}`, { responseType: 'text' });
  }

} 