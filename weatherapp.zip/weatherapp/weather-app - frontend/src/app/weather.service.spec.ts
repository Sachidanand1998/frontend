import { TestBed } from '@angular/core/testing';
import { WeatherService } from './weather.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('WeatherService', () => {
  let service: WeatherService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [WeatherService]
    });

    service = TestBed.inject(WeatherService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify(); 
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should retrieve weather data via GET', () => {
    const dummyWeather = {
      temperature: 20,
      humidity: 80
    };

    service.getWeather('Paris').subscribe(weather => {
      expect(weather).toEqual(dummyWeather);
    });

    const request = httpMock.expectOne(`http://localhost:9000/weather/city/Paris`);
    expect(request.request.method).toBe('GET');
    request.flush(dummyWeather);
  });
});
