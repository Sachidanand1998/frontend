import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  loginForm: FormGroup;
  message: string;

  constructor(private http: HttpClient, private router: Router, private formBuilder: FormBuilder, private snackBar: MatSnackBar) {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  ROOT_URL:String="http://authentication-devyanshi-env.eba-pjdecbtp.ap-northeast-1.elasticbeanstalk.com"

  login() {
    if (!this.loginForm.valid) {
      this.snackBar.open('Please fill all the fields correctly', 'Close', { duration: 3000 });
      return;
    }

    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    this.http.post<{token: string, message: string}>(this.ROOT_URL+'/auth/login', this.loginForm.value, { headers })
      .subscribe(response => {
        localStorage.setItem('token', response.token);
        console.log(response.token);
        localStorage.setItem('username', this.loginForm.value.username);
        this.router.navigate(['/search']);
      }, error => {
        this.message = error.error;
        this.snackBar.open(error.error, 'Close', { duration: 3000 });
      });
  }
}

