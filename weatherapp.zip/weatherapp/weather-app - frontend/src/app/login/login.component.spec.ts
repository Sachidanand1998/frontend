import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { of, throwError } from 'rxjs';
import { LoginComponent } from './login.component';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('LoginComponent', () => {
  let component: LoginComponent;
  let fixture: ComponentFixture<LoginComponent>;
  let httpClient: jasmine.SpyObj<HttpClient>;
  let router: jasmine.SpyObj<Router>;

  beforeEach(() => {
    const httpClientSpy = jasmine.createSpyObj('HttpClient', ['post']);
    httpClientSpy.post.and.returnValue(of({}));
    const routerSpy = jasmine.createSpyObj('Router', ['navigate']);

    TestBed.configureTestingModule({
      declarations: [ LoginComponent ],
      imports: [ MatCardModule, MatFormFieldModule, MatSnackBarModule, BrowserAnimationsModule ],
      providers: [
        { provide: HttpClient, useValue: httpClientSpy },
        { provide: Router, useValue: routerSpy }
      ]
    });

    fixture = TestBed.createComponent(LoginComponent);
    component = fixture.componentInstance;
    httpClient = TestBed.inject(HttpClient) as jasmine.SpyObj<HttpClient>;
    router = TestBed.inject(Router) as jasmine.SpyObj<Router>;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should login a user', () => {
    httpClient.post.and.returnValue(of({ token: 'testtoken', message: 'Logged in successfully' }));

    component.loginForm.setValue({ username: 'testuser', password: 'testpassword' });

    component.login();

    expect(httpClient.post.calls.count()).toBe(1, 'one call');
  });
  
  it('should handle login error', () => {
    const errorMessage = 'Login error';
    httpClient.post.and.returnValue(throwError({ error: errorMessage }));
  
    component.loginForm.setValue({ username: 'testuser', password: 'testpassword' });
  
    component.login();
  
    expect(component.message).toBe(errorMessage);
  });
  
  it('should not login a user with invalid input', () => {
    component.loginForm.setValue({ username: '', password: '' });

    component.login();

    expect(httpClient.post).not.toHaveBeenCalled();
  });
});
