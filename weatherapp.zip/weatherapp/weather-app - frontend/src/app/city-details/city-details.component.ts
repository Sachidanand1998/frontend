import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { WishlistService } from '../wishlist.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-city-details',
  templateUrl: './city-details.component.html',
  styleUrls: ['./city-details.component.css']
})
export class CityDetailsComponent implements OnInit {
  weatherDetails: any;
  city: string;
  message: string;

  constructor(private route: ActivatedRoute, private wishlistService: WishlistService, private router: Router, private snackBar: MatSnackBar) { }

  ngOnInit() {
    
    const weatherDetails = this.route.snapshot.paramMap.get('weatherDetails');
    const city = this.route.snapshot.paramMap.get('city');
    if (weatherDetails) {
      this.weatherDetails = JSON.parse(weatherDetails);
    }
    if (city) {
      this.city = city;
      // console.log(this.city);
    }
  }

  addToWishlist() {
    const username = localStorage.getItem('username') ?? '';
    const wishlistItem = {
      username: username,
      city: this.city
    };

    this.wishlistService.createWishlist(wishlistItem).subscribe(data => {
      this.snackBar.open('City added to wishlist successfully!', 'Close', { duration: 3000 });  // Open snackbar
    }, error => {
      this.snackBar.open('Failed to add city to wishlist.', 'Close', { duration: 3000 });  // Open snackbar
    });
  }
  
  goToWishlist() {
    this.router.navigate(['/wishlist']); 
    }
  }
