import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { CityDetailsComponent } from './city-details.component';
import { WeatherService } from '../weather.service';
import { WishlistService } from '../wishlist.service';
import { MatIconModule } from '@angular/material/icon';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('CityDetailsComponent', () => {
  let component: CityDetailsComponent;
  let fixture: ComponentFixture<CityDetailsComponent>;
  let weatherService: jasmine.SpyObj<WeatherService>;
  let wishlistService: jasmine.SpyObj<WishlistService>;

  beforeEach(() => {
    const weatherSpy = jasmine.createSpyObj('WeatherService', ['getWeather']);
    const wishlistSpy = jasmine.createSpyObj('WishlistService', ['createWishlist']);

    TestBed.configureTestingModule({
      declarations: [CityDetailsComponent],
      imports: [RouterTestingModule, MatSnackBarModule, MatIconModule, BrowserAnimationsModule],
      providers: [
        { provide: WeatherService, useValue: weatherSpy },
        { provide: WishlistService, useValue: wishlistSpy },
        { provide: ActivatedRoute, useValue: { snapshot: { paramMap: { get: () => '{}' } } } }
      ]
    });

    fixture = TestBed.createComponent(CityDetailsComponent);
    component = fixture.componentInstance;
    weatherService = TestBed.inject(WeatherService) as jasmine.SpyObj<WeatherService>;
    wishlistService = TestBed.inject(WishlistService) as jasmine.SpyObj<WishlistService>;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should add city to wishlist', () => {
    wishlistService.createWishlist.and.returnValue(of({}));

    component.addToWishlist();

    expect(wishlistService.createWishlist).toHaveBeenCalled();
  });

  it('should navigate to wishlist page', () => {
    const router = TestBed.inject(Router);
    const navigateSpy = spyOn(router, 'navigate');

    component.goToWishlist();

    expect(navigateSpy).toHaveBeenCalledWith(['/wishlist']);
  });
});
