import { CanActivateFn, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { inject } from '@angular/core';

export const authGuard: CanActivateFn = (
  route: ActivatedRouteSnapshot,
  state: RouterStateSnapshot
): boolean | UrlTree => {
  const router = inject(Router);
  const token = localStorage.getItem('token');
  if (token) {
    // Token exists, so the user is authenticated
    return true;
  } else {
    // No token, so redirect to login page
    return router.createUrlTree(['/login']);
  }
};