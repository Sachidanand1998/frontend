import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private logoutSubject = new Subject<void>();
  logoutObservable = this.logoutSubject.asObservable();

  private loginSubject = new Subject<string>();
  loginObservable = this.loginSubject.asObservable();

  constructor() { }

  logout() {
    this.logoutSubject.next();
  }

  login(username: string) {
    localStorage.setItem('username', username);
    this.loginSubject.next(username);
  }
  
}
