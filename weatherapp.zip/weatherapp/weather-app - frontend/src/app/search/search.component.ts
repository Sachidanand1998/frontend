import { Component } from '@angular/core';
import { WeatherService } from '../weather.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent {
  city: string;

  constructor(private weatherService: WeatherService, private router: Router) { }

  search() {
    this.weatherService.getWeather(this.city).subscribe(weatherDetails => {
      // Navigate to the city-details page with the weather details and the city name
      this.router.navigate(['/city-details', { weatherDetails: JSON.stringify(weatherDetails), city: this.city }]);
    });
  }
}
