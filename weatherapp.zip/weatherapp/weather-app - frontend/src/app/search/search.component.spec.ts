import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SearchComponent } from './search.component';
import { WeatherService } from '../weather.service';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import { MatCardModule } from '@angular/material/card';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('SearchComponent', () => {
  let component: SearchComponent;
  let fixture: ComponentFixture<SearchComponent>;
  let weatherService: WeatherService;
  let router: Router;

  beforeEach(() => {
    const weatherServiceMock = {
      getWeather: jasmine.createSpy('getWeather').and.returnValue(of({}))
    };

    const routerMock = {
      navigate: jasmine.createSpy('navigate')
    };

    TestBed.configureTestingModule({
      declarations: [SearchComponent],
      imports: [ MatCardModule, FormsModule, MatFormFieldModule, MatInputModule, BrowserAnimationsModule ],
      providers: [
        { provide: WeatherService, useValue: weatherServiceMock },
        { provide: Router, useValue: routerMock }
      ]
    });

    fixture = TestBed.createComponent(SearchComponent);
    component = fixture.componentInstance;
    weatherService = TestBed.inject(WeatherService);
    router = TestBed.inject(Router);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getWeather when search is called', () => {
    component.city = 'Test City';
    component.search();
    expect(weatherService.getWeather).toHaveBeenCalledWith('Test City');
  });

  it('should navigate to city-details when search is called', () => {
    component.city = 'Test City';
    component.search();
    expect(router.navigate).toHaveBeenCalled();
  });
});
