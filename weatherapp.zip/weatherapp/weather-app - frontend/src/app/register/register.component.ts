import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  username = new FormControl('', [Validators.required]);
  password = new FormControl('', [Validators.required, Validators.minLength(8)]);
  email = new FormControl('', [Validators.required, Validators.email]);
  name = new FormControl('', [Validators.required]);
  message: string;

  ROOT_URL:String="http://user-service-devyanshi-env.eba-h2kqnh9j.ap-northeast-1.elasticbeanstalk.com"

  constructor(private http: HttpClient, private router: Router) { }

  register() {
    if (this.username.valid && this.password.valid && this.email.valid && this.name.valid) {
      const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
      this.http.post<{message: string}>(this.ROOT_URL+'/users/register', { username: this.username.value, password: this.password.value, email: this.email.value, name: this.name.value }, { headers })
        .subscribe(response => {
          this.message = response.message;
          alert('User has been registered successfully');
        }, error => {
          this.message = error.error;
        });
    } else {
      alert('Please fill all the fields correctly');
    }
  }
}
