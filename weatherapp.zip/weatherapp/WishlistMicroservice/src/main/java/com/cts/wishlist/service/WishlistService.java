package com.cts.wishlist.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.wishlist.model.Wishlist;
import com.cts.wishlist.repository.WishlistRepository;

@Service
public class WishlistService {

	@Autowired
	private WishlistRepository wishlistRepository;

	public Wishlist saveWishlist(Wishlist wishlist) {
	    // Generate a new ID for each wishlist item
	    wishlist.setId(UUID.randomUUID().toString());
	    return wishlistRepository.save(wishlist);
	}

	public Wishlist getWishlist(String id) {
		Optional<Wishlist> wishlist = wishlistRepository.findById(id);
		if (wishlist.isPresent()) {
			return wishlist.get();
		} else {
			throw new RuntimeException("Wishlist not found for id: " + id);
		}
	}
	
	public List<Wishlist> getWishlistByUsername(String username) {
	    return wishlistRepository.findByUsername(username);
	}


	public void deleteWishlist(String id) {
		wishlistRepository.deleteById(id);
	}

}