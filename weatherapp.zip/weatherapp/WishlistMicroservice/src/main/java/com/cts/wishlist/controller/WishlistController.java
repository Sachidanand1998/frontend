package com.cts.wishlist.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.wishlist.model.Wishlist;
import com.cts.wishlist.service.WishlistService;

@RestController
@RequestMapping("/wishlist")
public class WishlistController {

	@Autowired
	private WishlistService wishlistService;

	@PostMapping("/add")
	public ResponseEntity<Wishlist> addWishlist(@RequestBody Wishlist wishlist) {
	    System.out.println("Adding wishlist: " + wishlist);  // Add this line
	    Wishlist savedWishlist = wishlistService.saveWishlist(wishlist);
	    return new ResponseEntity<>(savedWishlist, HttpStatus.CREATED);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Wishlist> getWishlist(@PathVariable String id) {
		try {
			Wishlist wishlist = wishlistService.getWishlist(id);
			return new ResponseEntity<>(wishlist, HttpStatus.OK);
		} catch (RuntimeException e) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	
	@GetMapping("/user/{username}")
	public ResponseEntity<List<Wishlist>> getWishlistByUsername(@PathVariable String username) {
	    try {
	        List<Wishlist> wishlist = wishlistService.getWishlistByUsername(username);
	        return new ResponseEntity<>(wishlist, HttpStatus.OK);
	    } catch (RuntimeException e) {
	        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
	}


	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteWishlist(@PathVariable String id) {
		wishlistService.deleteWishlist(id);
		return new ResponseEntity<>("Deleted successfully", HttpStatus.OK);
	}
}
