package com.cts.wishlist.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "wishlist")
public class Wishlist {

	@Id
	private String id;
	private String username;
	private String city;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Wishlist(String id, String username, String city) {
		super();
		this.id = id;
		this.username = username;
		this.city = city;
	}
	public Wishlist() {
		super();
	}
	@Override
	public String toString() {
		return "Wishlist [id=" + id + ", username=" + username + ", city=" + city + "]";
	}
	

}
