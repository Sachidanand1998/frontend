package com.cts.wishlist.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.cts.wishlist.model.Wishlist;

public interface WishlistRepository extends MongoRepository<Wishlist, String> {
    List<Wishlist> findByUsername(String username);
}

//@Repository
//public interface WishlistRepository extends MongoRepository<Wishlist, String> {
//	Optional<Wishlist> findById(String id);
//}
