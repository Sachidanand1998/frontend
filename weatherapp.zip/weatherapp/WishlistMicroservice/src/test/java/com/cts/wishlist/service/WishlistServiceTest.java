//package com.cts.wishlist.service;
//
//import static org.junit.Assert.assertEquals;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import com.cts.wishlist.model.City;
//import com.cts.wishlist.repository.WishlistRepository;
//
//@RunWith(SpringRunner.class)
//@SpringBootTest
//public class WishlistServiceTest {
//    @Autowired
//    private WishlistService wishlistService;
//
//    @MockBean
//    private WishlistRepository wishlistRepository;
//
//    @Test
//    public void getWishlistTest() {
//        List<City> wishlist = new ArrayList<>();
//        // Add some cities to the wishlist
//
//        when(wishlistRepository.findByEmail(toString())).thenReturn(wishlist);
//
//        List<City> result = wishlistService.getWishlist("test@example.com");
//
//        assertEquals(wishlist, result);
//    }
//
//    @Test
//    public void addToWishlistTest() {
//        City city = new City();
//        // Set the properties of the city object
//
//        when(wishlistRepository.save(any(City.class))).thenReturn(city);
//
//        City result = wishlistService.addToWishlist("test@example.com", city);
//
//        assertEquals(city, result);
//    }
//}
