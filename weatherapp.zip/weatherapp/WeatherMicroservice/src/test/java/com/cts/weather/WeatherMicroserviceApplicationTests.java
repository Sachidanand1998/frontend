//package com.cts.weather;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.when;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.web.client.RestTemplate;
//
//import com.cts.weather.model.Weather;
//import com.cts.weather.service.WeatherService;
//
//@SpringBootTest
//public class WeatherMicroserviceApplicationTests {
//
//    @MockBean
//    private RestTemplate restTemplate;
//
//    @MockBean
//    private WeatherService weatherService;
//
//    @Test
//    public void testGetWeather() {
//        String city = "London";
//        Weather weather = new Weather(city);
//
//        when(weatherService.getWeather(city)).thenReturn(weather);
//        Weather responseWeather = weatherService.getWeather(city);
//
//        assertEquals(responseWeather.getCity(), city);
//    }
//}
//
