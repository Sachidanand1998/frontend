//package com.cts.weather.controller;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.http.ResponseEntity;
//
//import com.cts.weather.model.Weather;
//import com.cts.weather.service.WeatherService;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.when;
//
//@SpringBootTest
//public class WeatherControllerTest {
//
//    @MockBean
//    private WeatherService weatherService;
//
//    @Test
//    public void testGetWeather() {
//        String city = "London";
//        Weather weather = new Weather(city);
//
//        when(weatherService.getWeather(city)).thenReturn(weather);
//        WeatherController weatherController = new WeatherController();
//
//        ResponseEntity<Weather> responseEntity = weatherController.getWeather(city);
//
//        assertEquals(responseEntity.getBody().getCity(), city);
//    }
//}
