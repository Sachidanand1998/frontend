package com.cts.weather.model;

public class Weather {

	private String city;

	// getters and setters
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Weather(String city) {
		super();
		this.city = city;
	}


}
