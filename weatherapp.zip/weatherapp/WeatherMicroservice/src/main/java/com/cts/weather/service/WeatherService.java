package com.cts.weather.service;

import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.cts.weather.exception.AuthenticationException;
import com.cts.weather.model.Weather;

import reactor.core.publisher.Mono;

@Service
public class WeatherService {
    private final WebClient webClient;
    private final String weatherApiUrl = "http://api.openweathermap.org/data/2.5/weather";
    private final String apiKey = "63f7d396113bacf5d5a6e4c4da0efd6a";
    private final String authServiceUrl = "http://localhost:8081/auth/validateToken"; //auth service url

    public WeatherService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl(weatherApiUrl).build();
    }

    public Mono<Weather> getWeather(String city) {
        String url = String.format("%s?q=%s&appid=%s", weatherApiUrl, city, apiKey);
        return webClient.get().uri(url).retrieve().bodyToMono(Weather.class);
    }

    public Mono<Boolean> validateToken(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", token);
        return WebClient.create(authServiceUrl)
                .get()
                .uri(uriBuilder -> uriBuilder.build())
                .headers(httpHeaders -> httpHeaders.setAll(headers.toSingleValueMap()))
                .retrieve()
                .bodyToMono(Boolean.class)
                .onErrorResume(e -> Mono.error(new AuthenticationException("Invalid or expired token")));
    }
}







//@Service
//public class WeatherService {
//	private final RestTemplate restTemplate;
//	private final String weatherApiUrl = "http://api.openweathermap.org/data/2.5/weather";
//	private final String apiKey = "63f7d396113bacf5d5a6e4c4da0efd6a";
//	private final String authServiceUrl = "http://localhost:8081/auth/validateToken"; // replace with your auth service
//																						// url
//
//	public WeatherService(RestTemplateBuilder restTemplateBuilder) {
//		this.restTemplate = restTemplateBuilder.build();
//	}
//
//	public Weather getWeather(String city) {
//		String url = String.format("%s?q=%s&appid=%s", weatherApiUrl, city, apiKey);
//		return restTemplate.getForObject(url, Weather.class);
//	}
//
//	public boolean validateToken(String token) {
//		HttpHeaders headers = new HttpHeaders();
//		headers.set("Authorization", token);
//		HttpEntity<String> entity = new HttpEntity<>("parameters", headers);
//		try {
//			ResponseEntity<Boolean> response = restTemplate.exchange(authServiceUrl, HttpMethod.GET, entity,
//					Boolean.class);
//			return response.getBody();
//		} catch (HttpClientErrorException e) {
//			throw new AuthenticationException("Invalid or expired token");
//		}
//	}
//}








// private final RestTemplate restTemplate;
// private final String weatherApiUrl =
// "http://api.openweathermap.org/data/2.5/weather";
// private final String apiKey = "63f7d396113bacf5d5a6e4c4da0efd6a";
//
// public WeatherService(RestTemplateBuilder restTemplateBuilder) {
// this.restTemplate = restTemplateBuilder.build();
// }
//
// public Weather getWeather(String city) {
// String url = String.format("%s?q=%s&appid=%s", weatherApiUrl, city, apiKey);
// return restTemplate.getForObject(url, Weather.class);
// }