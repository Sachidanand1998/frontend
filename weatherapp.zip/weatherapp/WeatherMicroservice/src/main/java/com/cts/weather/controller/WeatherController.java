package com.cts.weather.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.weather.exception.AuthenticationException;
import com.cts.weather.model.Weather;
import com.cts.weather.service.WeatherService;

import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/weather")
public class WeatherController {
    private final WeatherService weatherService;

    public WeatherController(WeatherService weatherService) {
        this.weatherService = weatherService;
    }

    @GetMapping("/{city}")
    public Mono<ResponseEntity<Weather>> getWeather(@PathVariable String city, @RequestHeader("Authorization") String token) {
        return weatherService.validateToken(token)
                .flatMap(valid -> {
                    if (Boolean.TRUE.equals(valid)) {
                        return weatherService.getWeather(city)
                                .map(ResponseEntity::ok)
                                .defaultIfEmpty(ResponseEntity.notFound().build());
                    } else {
                        throw new AuthenticationException("Invalid or expired token");
                    }
                });
    }
}












//@RestController
//@RequestMapping("/weather")
//public class WeatherController {
//	@Autowired
//	private WeatherService weatherService;
//
//	@GetMapping("/{city}")
//	public ResponseEntity<Weather> getWeather(@PathVariable String city, @RequestHeader("Authorization") String token) {
//		if (weatherService.validateToken(token)) {
//			return ResponseEntity.ok(weatherService.getWeather(city));
//		} else {
//			throw new AuthenticationException("Invalid or expired token");
//		}
//	}
//}
