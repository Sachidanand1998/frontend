package com.weather.cts.auth.exception;

public class UserCredentialsMisMatch extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserCredentialsMisMatch(String msg) {
		super(msg);
	}

}
