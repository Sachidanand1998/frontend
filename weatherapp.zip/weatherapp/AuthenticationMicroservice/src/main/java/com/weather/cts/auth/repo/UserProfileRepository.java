package com.weather.cts.auth.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.weather.cts.auth.model.UserProfiles;

@Repository
public interface UserProfileRepository extends JpaRepository<UserProfiles, Long> {
	UserProfiles findByUsernameAndPassword(String username, String password);

	UserProfiles findByUsername(String username);
}
