package com.weather.cts.auth.exception;

public class UserCredentialsNullException extends RuntimeException{
	public UserCredentialsNullException(String msg){
		super(msg);
	}

}