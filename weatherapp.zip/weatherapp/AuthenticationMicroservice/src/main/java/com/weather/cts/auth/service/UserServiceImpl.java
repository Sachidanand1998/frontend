package com.weather.cts.auth.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.weather.cts.auth.exception.InvalidTokenException;
import com.weather.cts.auth.model.User;
import com.weather.cts.auth.model.UserProfiles;
import com.weather.cts.auth.repo.UserProfileRepository;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class UserServiceImpl {
	String secretkey = "secret";
	@Autowired
	UserProfileRepository userProfileRepository;

	public UserProfiles findByUsername(String username) {
		return userProfileRepository.findByUsername(username);
	}

	public Map<String, String> generateToken(User userCredentials) {
		Map<String, String> jwtTokenMap = new HashMap<>();
		if (userCredentials != null && userCredentials.getUsername() != null) {
			String token = Jwts.builder().setSubject(userCredentials.getUsername())
					.setIssuedAt(new Date(System.currentTimeMillis()))
					.setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60)) // token for 60 min
					.signWith(SignatureAlgorithm.HS256, secretkey).compact();
			jwtTokenMap.put("token", token);
			jwtTokenMap.put("message", "Login Successful");
		} else {
			jwtTokenMap.put("message", "Invalid user credentials");
		}
		return jwtTokenMap;
	}

	public Boolean validateToken(String token) {
		try {
			Jwts.parser().setSigningKey(secretkey).parseClaimsJws(token);
			return true;
		} catch (Exception e) {
			// Log the exception for debugging purposes
			System.out.println("Invalid or expired token: " + e.getMessage());
			return false;
		}
	}

	public String getUsernameFromToken(String token) throws InvalidTokenException {
		if (validateToken(token)) {
			return Jwts.parser().setSigningKey(secretkey).parseClaimsJws(token).getBody().getSubject();
		} else {
			throw new InvalidTokenException("Invalid or expired token");
		}
	}
	public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = extractAllClaims(token);
		return claimsResolver.apply(claims);
	}

	private Claims extractAllClaims(String token) {
		return Jwts.parser().setSigningKey(secretkey).parseClaimsJws(token).getBody();
	}
}