package com.weather.cts.auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.weather.cts.auth.exception.InvalidTokenException;
import com.weather.cts.auth.exception.UserCredentialsMisMatch;
import com.weather.cts.auth.exception.UserCredentialsNullException;
import com.weather.cts.auth.exception.UserNotFoundException;
import com.weather.cts.auth.model.User;
import com.weather.cts.auth.model.UserProfiles;
import com.weather.cts.auth.service.UserServiceImpl;

@RestController
@RequestMapping("/auth")
public class AuthController {
	@Autowired
	private UserServiceImpl userService;

	@PostMapping("/login")
	public ResponseEntity<?> loginUser(@RequestBody User user) throws InvalidTokenException {
		try {
			validateUserCredentials(user);
			validateUserPassword(user);
			return new ResponseEntity<>(userService.generateToken(user), HttpStatus.OK);
		} catch (UserCredentialsMisMatch e) {
	        return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
	    } catch (Exception e) {
	        return new ResponseEntity<>("Username not found.", HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	}

	@GetMapping("/validateToken")
	public boolean validateUser(@RequestHeader("Authorization") String token) {
		return userService.validateToken(token);
	}

	@GetMapping("/username")
	public ResponseEntity<?> getUsername(@RequestHeader("Authorization") String token) {
		try {
			String username = userService.getUsernameFromToken(token);
			return new ResponseEntity<>(username, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
		}
	}

	private void validateUserCredentials(User user) {
	    if (user.getUsername() == null || user.getPassword() == null) {
	        throw new UserCredentialsNullException("Username and password cannot be null");
	    }
	    UserProfiles userProfile = userService.findByUsername(user.getUsername());
	    if (userProfile == null) {
	        throw new UserNotFoundException("Username not found");
	    }
	}


	private void validateUserPassword(User user) {
		UserProfiles userProfile = userService.findByUsername(user.getUsername());
		if (!user.getPassword().equals(userProfile.getPassword())) {
			throw new UserCredentialsMisMatch("Invalid Password");
		}
	}
}