package com.weather.cts.auth.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.weather.cts.auth.model.UserProfiles;
import com.weather.cts.auth.repo.UserProfileRepository;

@RunWith(MockitoJUnitRunner.class)
public class UserServiceImplTest {

    @InjectMocks
    private UserServiceImpl userService;

    @Mock
    private UserProfileRepository userProfileRepository;

    @Test
    public void testFindByUsername() {
        String username = "test";
        UserProfiles userProfiles = new UserProfiles();
        userProfiles.setUsername(username);

        when(userProfileRepository.findByUsername(username)).thenReturn(userProfiles);

        UserProfiles result = userService.findByUsername(username);

        assertNotNull(result);
        assertEquals(username, result.getUsername());

        verify(userProfileRepository, times(1)).findByUsername(username);
    }

}
