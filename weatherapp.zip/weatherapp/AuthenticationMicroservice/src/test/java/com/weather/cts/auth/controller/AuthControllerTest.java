//package com.weather.cts.auth.controller;
//
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.MockitoJUnitRunner;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//
//import com.weather.cts.auth.model.User;
//import com.weather.cts.auth.service.UserServiceImpl;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import static org.junit.Assert.*;
//import static org.mockito.Mockito.*;
//
//@RunWith(MockitoJUnitRunner.class)
//public class AuthControllerTest {
//
//    @InjectMocks
//    private AuthController authController;
//
//    @Mock
//    private UserServiceImpl userService;
//
//    @Test
//    public void testLoginUser() {
//        User user = new User();
//        user.setUsername("test");
//        user.setPassword("test");
//
//        Map<String, String> tokenMap = new HashMap<>();
//        tokenMap.put("token", "testToken");
//        tokenMap.put("message", "Login Successful");
//
//        when(userService.generateToken(user)).thenReturn(tokenMap);
//
//        ResponseEntity<?> response = authController.loginUser(user);
//
//        assertNotNull(response);
//        assertEquals(HttpStatus.OK, response.getStatusCode());
//        assertEquals(tokenMap, response.getBody());
//
//        verify(userService, times(1)).generateToken(user);
//    }
//
//}
//
