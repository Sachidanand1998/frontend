package com.cts.moviebooking.exception;

public class MovieBookingException extends RuntimeException {
    public MovieBookingException(String message) {
        super(message);
    }
}
