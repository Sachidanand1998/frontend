package com.cts.moviebooking.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cts.moviebooking.util.CustomObjectMapper;

@Configuration
public class JacksonConfig {

    @Bean
    public CustomObjectMapper customObjectMapper() {
        return new CustomObjectMapper();
    }
}
