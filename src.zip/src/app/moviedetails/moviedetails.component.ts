import { Component, OnInit } from '@angular/core';
import { MovieService } from '../services/movie.service';
import { AuthServiceService } from '../services/auth-service.service';
import { Movie } from '../_models/movie';

@Component({
  selector: 'app-moviedetails',
  templateUrl: './moviedetails.component.html',
  styleUrls: ['./moviedetails.component.css']
})
export class MoviedetailsComponent implements OnInit {

  movie: any[]=[];
  constructor(private movieService: MovieService, private authService: AuthServiceService) {}
ngOnInit(): void {
  this.getMoviesByCountry("india");
}
  // Add a method to trigger the service
  getMoviesByCountry(country: string) {
    // Use your authentication service to get the token
    this.movieService.getMoviesByCountry(country).subscribe(
      (response) => {
        console.log(response);
        this.movie=response.body;
        // Handle the response here
      },
      (error) => {
        console.error(error);
        // Handle errors here
      }
    );
  }
  dummyData = [
    {
      "symbol": "08GPG",
      "name": "Nippon India Mutual Fund",
      "currency": "INR",
      "exchange": "BSE",
      "mic_code": "XBOM",
      "country": "India",
      "type": "Common Stock",
      "extraField": "Dummy Extra Data"
    },
    // Add more dummy data if needed
  ];


  onButtonClick(data: any) {
    // Handle button click for the specific data row
    console.log('Button clicked for:', data);
  }
}
