import { Component } from '@angular/core';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent {
  dummyData = [
    {
      "symbol": "08GPG",
      "name": "Nippon India Mutual Fund",
      "currency": "INR",
      "exchange": "BSE",
      "mic_code": "XBOM",
      "country": "India",
      "type": "Common Stock",
      "extraField": "Dummy Extra Data"
    },
    // Add more dummy data if needed
  ];


  onButtonClick(data: any) {
    // Handle button click for the specific data row
    console.log('Button clicked for:', data);
  }
}


